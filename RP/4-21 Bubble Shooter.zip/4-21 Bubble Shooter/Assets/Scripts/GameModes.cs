﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameModes : MonoBehaviour
{
    /* Changes to the Classic Game Scene when "Classic" option is chosen */
    public void PlayClassic()
    {
        SceneManager.LoadScene("Testing 1");
    }

    /* Changes to the Main Menu screen when "Back" option is chosen */
    public void GoBack()
    {
        SceneManager.LoadScene("MainMenuScene");
    }
}
