﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bubble : MonoBehaviour {

    public Transform shooter;
    public static bool isFired;
    public static bool once;
    public static bool swallHit;
    public static bool rotating;
    public GameObject StaticBall;
    public GameObject shooterBubble;
    public GameObject [] SpawnedBubble;
    public Rigidbody2D rb;
    public Transform newbubblepos;
    public float movespeed = 10f;


    // Start is called before the first frame update
    void Start()
    {
    
        isFired = false;
        once = false;
        Debug.Log("INSTANTIATE");
        //startBubble = (GameObject)Instantiate(SpawnedBubble[1], transform);
        //startBubble.transform.position = new Vector2((float)0.1761411, (float) -0.1233155);
        //startBubble.transform.position = gameObject.transform.position;
        //startBubble = gameObject;
        //estroy(gameObject);

    }

    // Update is called once per frame
    void Update()
    {
        
        rotating = true;
        if(Input.GetKeyDown("space"))
        {
            if(once == false){
            isFired = true;
            rotating = false;
            once = true;
            }
              
        }
        
        if(isFired)
        {

        //transform.Translate(Vector3.up * Time.deltaTime * movespeed);
       // rb.velocity = new Vector3(10, 10, 0);
        //rb.AddRelativeForce(Vector2.up, ForceMode2D.Impulse);
        FIRE();
        isFired = false;
      // rb.AddForceAtPosition()
       // xcoord = rb.velocity.x;
       // ycoord = rb.velocity.y;
      //  rb.velocity = new Vector2(xcoord,ycoord);
      

        transform.parent = null;
       // Vector3 vel = rb.velocity;
        //transform.position += vel * Time.deltaTime;
        
           // transform.position =  Vector3.up * Time.deltaTime;
        } else if(rotating)
        {
            transform.rotation = shooter.rotation;
        }

        if (shooterBubble == null)
        {
            shooterBubble = (GameObject)Instantiate(SpawnedBubble[1], transform);
            shooterBubble.transform.position = new Vector2((float)-0.3, (float) -4.2);
        }
    }

    public void StopBubble()
    {
        
       /* 
        GameObject newbub;
         if(gameObject != null)
         {
            //Instantiate(StaticBall, rb.position, Quaternion.identity);
            newbub = Instantiate(SpawnedBubble[1], newbubblepos.position, Quaternion.identity);
            newbub.transform.SetParent(newbubblepos.transform);

         }

        //Destroy(gameObject);
        //gameObject = newbub;
        */
         
    }

    public void FIRE()
{
    rb.AddRelativeForce(Vector2.up * movespeed, ForceMode2D.Impulse);

}
}

