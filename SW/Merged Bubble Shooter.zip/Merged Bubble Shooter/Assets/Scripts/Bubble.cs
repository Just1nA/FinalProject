﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bubble : MonoBehaviour {

    public Transform shooter;
    public static bool isFired;
    public static bool once;
    public Rigidbody2D rb;
    //public Transform Axis;
    public float movespeed = 10f;


    // Start is called before the first frame update
    void Start()
    {
        
        isFired = false;
        once = false;
        //Debug.Log("INSTANTIATE");
       

    }

    // Update is called once per frame
    void Update()
    {

        if(Input.GetKeyDown("space"))
        {
            if(once == false)
            {
                isFired = true;
                once = true;
            }
              
        }
        
        if(isFired)
        {
          FIRE();
          isFired = false;
        } 
    }

    public void StopBubble()
    {
        Destroy(gameObject);     
    }

    public void FIRE()
    {
        rb.AddRelativeForce(Vector2.up * movespeed, ForceMode2D.Impulse);

    }
}

