﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BubbleOnBoard : MonoBehaviour
{
    public static int boardI;
    public static int boardJ;
    
    public Transform Bobposition;
    void OnTriggerEnter2D (Collider2D col) 
    {
        if(col.tag == "Bubble")
        {
            Debug.Log("Bubble On Board" + Bobposition.position);
            Debug.Log("Shooter Bubble" + col.GetComponent<Bubble>().rb.position);
            calculateCoordinates(col.GetComponent<Bubble>().rb.position.x,col.GetComponent<Bubble>().rb.position.y);
            col.GetComponent<Bubble>().rb.velocity = Vector3.zero;
            col.GetComponent<Bubble>().StopBubble();
        }
        
    }

    void calculateCoordinates (double shooterX, double shooterY)
    {
        double shooterRow;
        double shooterCol;
        
        Debug.Log("Shooter x = " + shooterX + "\t Shooter y= " + shooterY);

        /* Converting from i and j in the grid */
        //shooterCol = Mathf.RoundToInt((float)shooterCol);
        //shooterRow = Mathf.RoundToInt((float)shooterRow);
/*
        shooterRow = 5 + shooterY;
        if(shooterRow % 2 == 1) shooterCol = 4.5 + shooterX;
        else shooterCol = 4 + shooterX;

        shooterRow = shooterRow + 1;
*/
        int IntX;
        shooterCol = 5.5 + shooterY;
        if(shooterCol % 2 == 1) shooterRow = 4.5 + shooterX;
        else shooterRow = 4 + shooterX;

        IntX = Mathf.RoundToInt((float)shooterRow);
        if(shooterRow - IntX < 0.25)
        {
            boardI = IntX - 1;
        }
        else boardI = IntX + 1;
        Debug.Log("Shooter col = " + shooterCol + "\t Shooter row = " + shooterRow);
        boardJ = Mathf.RoundToInt((float)shooterCol);
        //boardI = Mathf.RoundToInt((float)shooterRow);
        Debug.Log("BoardJ = " + boardJ + "\t BoardI = " + boardI);        
    }

}
