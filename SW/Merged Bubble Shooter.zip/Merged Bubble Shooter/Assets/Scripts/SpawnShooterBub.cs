﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnShooterBub : MonoBehaviour
{
    public GameObject[] shooterBubs;
    public static GameObject shooterBub;
    public static int sIndex;
    public Transform Axis;
    public Transform shooter;

    // Start is called before the first frame update
    void Start()
    {
        sIndex = getRandom();
        shooterBub = (GameObject)Instantiate(shooterBubs[sIndex], transform.position, Quaternion.identity);
        shooterBub.transform.position = new Vector2((float)-0.17, (float) -4.05);
        shooterBub.transform.SetParent(Axis.transform);
    }

    // Update is called once per frame
    void Update()
    {
        if (shooterBub == null)
        {
            sIndex = getRandom();
            shooterBub = (GameObject)Instantiate(shooterBubs[sIndex], transform.position, Quaternion.identity);
            shooterBub.transform.position = new Vector2((float)-0.2786695, (float) -4.109471);
            //shooterBub.transform.SetParent(shooter.transform);
            shooterBub.transform.SetParent(Axis.transform);
            
        }      

        if (shooterBub != null)
        {
            shooterBub.transform.rotation = shooter.transform.rotation;
        }
    
    }

    /* Get a random element of the bubbles GameObject array */
    private int getRandom()
    {
        int randomNum = Random.Range(1, shooterBubs.Length);
        return randomNum;
    }

}
