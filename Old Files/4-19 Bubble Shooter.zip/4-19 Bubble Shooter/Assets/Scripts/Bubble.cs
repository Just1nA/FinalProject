﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bubble : MonoBehaviour {

    public Transform shooter;
    public static bool isFired;
    public static bool once;
    public static bool stopBubbleCalled;
    public Rigidbody2D rb;
    //public Transform Axis;
    public float movespeed;


    // Start is called before the first frame update
    void Start()
    {
        //New bubble spawned and all bools are set
        isFired = false;
        once = false;
        stopBubbleCalled = false;
        //Debug.Log("INSTANTIATE");
    }

    // Update is called once per frame
    void Update()
    {

        if(Input.GetKeyDown("space"))
        {
            //Ensures the movement command is only initiated once
            if(once == false)
            {
                isFired = true;
                once = true;
            }
              
        }
        
        //Calls movement command and resets isFired
        if(isFired)
        {
          FIRE();
          isFired = false;
        } 
    }

    //Changes stopBubbleCalled bool and deletes moving object
    public void StopBubble()
    {
        stopBubbleCalled = true;  
        Destroy(gameObject);    
    }

    //Applies force to object
    public void FIRE()
    {
        rb.AddRelativeForce(Vector2.up * movespeed, ForceMode2D.Impulse);

    }
}

