﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnShooterBub : MonoBehaviour
{
    public GameObject[] shooterBubs;
    public static GameObject shooterBub;
    public static int sIndex;
    public Transform Axis;
    public Transform shooter;

    /* Start shooter instantiate */
    void Start()
    {
        sIndex = getRandom();
        shooterBub = (GameObject)Instantiate(shooterBubs[sIndex], transform.position, Quaternion.identity);
        shooterBub.transform.position = new Vector2((float)-0.158, (float) -4.561);
        shooterBub.transform.SetParent(Axis.transform);
    }

    /* Late update to prevent getting wrong color index */
    void LateUpdate()
    {   
        //Create new shooter bubble when it is empty
        if (shooterBub == null)
        {
            sIndex = getRandom();
            shooterBub = (GameObject)Instantiate(shooterBubs[sIndex], transform.position, Quaternion.identity);
            shooterBub.transform.position = new Vector2((float)-0.158, (float) -4.561);
            //shooterBub.transform.SetParent(shooter.transform);
            shooterBub.transform.SetParent(Axis.transform);
            
        }      

        //When gameobject is not empty, get rotation from shooter
        if (shooterBub != null)
        {
            shooterBub.transform.rotation = shooter.transform.rotation;
        }
    
    }

    /* Get a random element of the bubbles GameObject array */
    private int getRandom()
    {
        int randomNum = Random.Range(1, shooterBubs.Length);
        return randomNum;
    }

}
