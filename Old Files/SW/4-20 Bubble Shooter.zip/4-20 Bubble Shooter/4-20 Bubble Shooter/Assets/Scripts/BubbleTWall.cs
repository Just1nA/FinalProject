﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BubbleTWall : MonoBehaviour
{
    public static int boardI;
    public static int boardJ;
   void OnTriggerEnter2D (Collider2D col) 
    {
    
     //   Debug.Log("IT HIT SOMETHING");
        if(col.tag == "Bubble")
        {
            calculateCoordinates(col.GetComponent<Bubble>().gameObject.transform.localPosition.x, col.GetComponent<Bubble>().gameObject.transform.localPosition.y);
            col.GetComponent<Bubble>().rb.velocity = Vector3.zero;
            col.GetComponent<Bubble>().StopBubble();
        }
        
    }

    void calculateCoordinates (double shooterX, double shooterY)
    {
        boardJ = Mathf.RoundToInt((float)shooterY);
        
        //Offset for local board
        if (boardJ % 2 == 0) shooterX -= 0.5;

        boardI = Mathf.RoundToInt((float)shooterX);
        if (boardI >= GridManager.col) boardI -= 1;
        if (boardI < 0) boardI = 0;
        Debug.Log("BoardI = " + boardI + "\t BoardJ = " + boardJ);        
    }

}
