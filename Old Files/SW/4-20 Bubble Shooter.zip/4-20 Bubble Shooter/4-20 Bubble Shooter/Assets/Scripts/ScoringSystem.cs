﻿using UnityEngine;
using UnityEngine.UI;

public class ScoringSystem : MonoBehaviour
{
    public Text scoreText;
    public int test;
    // Start is called before the first frame update
   

    // Update is called once per frame
    void Update()
    {
        scoreText.text = test.ToString();

        test = test + 1;
    }
}
